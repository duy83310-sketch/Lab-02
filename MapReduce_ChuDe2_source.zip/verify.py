#!/usr/bin/env python3
"""Doi soat doc lap: tinh Top 2 truc tiep tu danh sach ke (khong MapReduce)
roi so sanh voi output.txt.  Dung: python3 verify.py input.txt output.txt"""
import sys
from collections import defaultdict

adj = defaultdict(set)
users = set()
for line in open(sys.argv[1], encoding="utf-8"):
    line = line.strip()
    if not line:
        continue
    u, _, rest = line.replace(":", "\t", 1).partition("\t") if "\t" not in line else line.partition("\t")
    u = u.strip()
    users.add(u)
    for f in (x.strip() for x in rest.split(",")):
        if f and f != u:
            adj[u].add(f); adj[f].add(u); users.add(f)   # quan he vo huong

expected = {}
for u in users:
    score = defaultdict(int)
    for x in adj[u]:
        for v in adj[x]:
            if v != u and v not in adj[u]:
                score[v] += 1
    top = sorted(score.items(), key=lambda t: (-t[1], t[0]))[:2]
    expected[u] = ", ".join(f"{c} ({s})" for c, s in top) or "Không có gợi ý (0)"

actual = dict(l.rstrip("\n").split("\t", 1) for l in open(sys.argv[2], encoding="utf-8") if "\t" in l)
ok = expected == actual
print("is_identical =", ok)
if not ok:
    for u in sorted(set(expected) | set(actual)):
        if expected.get(u) != actual.get(u):
            print(u, "| ky vong:", expected.get(u), "| thuc te:", actual.get(u))
sys.exit(0 if ok else 1)
